/* Newb Shader
   MISCELLANEOUS SETTINGS
   see readme.txt for instructions
*/


/*""""""""""""""""""""""""""""""""""""""*/
/* SUN & MOON */

// Toggle + Value - Rotate sun/moon (angle in degrees)
//#define ROTATE_SUNMOON 45.0

/*""""""""""""""""""""""""""""""""""""""*/


/*""""""""""""""""""""""""""""""""""""""*/
/* GUI TOUCH CIRCLE */

// Value - Touch circle visibility
#define circle_invert_value 0.5

/*""""""""""""""""""""""""""""""""""""""*/
