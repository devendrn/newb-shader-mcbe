/* Newb Shader
   MAIN SETTINGS
   terrain,entities,banner,clouds
   see readme.txt for instructions
*/


/*""""""""""""""""""""""""""""""""""""""*/
/* TIME */

// Toggle - Use real world time for wave effects
// Disable this if you have static wave bug
#define USE_REAL_WORLD_TIME

/*""""""""""""""""""""""""""""""""""""""*/


/*""""""""""""""""""""""""""""""""""""""*/
/* LIGHTING */

// Value - Sunlight brightness
#define sun_intensity 2.6

/*""""""""""""""""""""""""""""""""""""""*/

